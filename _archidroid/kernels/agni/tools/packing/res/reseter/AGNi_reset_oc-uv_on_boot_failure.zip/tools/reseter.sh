#!/sbin/busybox sh

## PSN>> AGNi CPU,GPU OC-UV user settings reseter

chmod +x /tmp/busybox;
/tmp/busybox rm /system/etc/init.d/*bkcpu*;
/tmp/busybox rm /system/etc/init.d/*bkgpu*;

